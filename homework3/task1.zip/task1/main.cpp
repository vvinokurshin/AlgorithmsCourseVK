#include <iostream>

int main(void) {
    std::cout << "Hello, world" << std::endl;

    return 0;
}